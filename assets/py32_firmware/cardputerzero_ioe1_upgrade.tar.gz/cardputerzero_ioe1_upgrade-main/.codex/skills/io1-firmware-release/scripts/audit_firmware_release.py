#!/usr/bin/env python3
"""Audit CardputerZero IOE1 firmware release docs and checksums."""

from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path


FIRMWARE_RE = re.compile(
    r"^app_without_flash_(?P<version>[^_]+)_(?P<clock>[^()]+)"
    r"\((?P<addresses>[^)]+)\)_(?P<minor>0x[0-9a-fA-F]+)\.h$"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_length(path: Path) -> int | None:
    text = path.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r"\bappHexLength\s*=\s*(0x[0-9a-fA-F]+|\d+)", text)
    return int(match.group(1), 0) if match else None


def expected_sha_lines(root: Path, firmware_files: list[Path]) -> list[str]:
    paths = [root / "upgrade_io1.py", *firmware_files]
    return [f"{sha256(path)}  {path.relative_to(root).as_posix()}" for path in paths]


def audit(root: Path, write_sha256: bool) -> int:
    issues: list[str] = []
    firmware_dir = root / "firmwares"
    firmware_files = sorted(firmware_dir.glob("*.h"))

    required = [root / "upgrade_io1.py", root / "README.md", firmware_dir / "README.md"]
    for path in required:
        if not path.exists():
            issues.append(f"missing required file: {path.relative_to(root)}")

    if not firmware_files:
        issues.append("no firmware headers found under firmwares/*.h")

    infos = []
    for path in firmware_files:
        match = FIRMWARE_RE.match(path.name)
        if not match:
            issues.append(f"unexpected firmware filename: {path.relative_to(root)}")
            continue
        infos.append((path, match.groupdict(), parse_length(path)))

    print("Bundled firmware:")
    for path, data, length in infos:
        length_text = "unknown length" if length is None else f"{length} bytes"
        minor = f"0x{int(data['minor'], 16):02X}"
        print(f"  {path.name}: {minor}, {data['version']}, {data['clock']}, {length_text}")
        if length is None:
            issues.append(f"missing appHexLength in {path.relative_to(root)}")

    for doc in [root / "README.md", firmware_dir / "README.md"]:
        if not doc.exists():
            continue
        text = doc.read_text(encoding="utf-8", errors="ignore")
        for path, data, _length in infos:
            if path.name not in text:
                issues.append(f"{doc.relative_to(root)} does not mention {path.name}")
            if data["minor"].upper() not in text.upper():
                issues.append(f"{doc.relative_to(root)} does not mention {data['minor'].upper()}")

    sha_path = root / "SHA256SUMS.txt"
    expected = expected_sha_lines(root, firmware_files) if (root / "upgrade_io1.py").exists() else []
    if write_sha256 and expected:
        sha_path.write_text("\n".join(expected) + "\n", encoding="utf-8")
        print(f"wrote {sha_path.relative_to(root)}")

    if expected:
        actual = sha_path.read_text(encoding="utf-8", errors="ignore").splitlines() if sha_path.exists() else []
        missing = [line for line in expected if line not in actual]
        stale = [line for line in actual if line and line not in expected]
        for line in missing:
            issues.append(f"SHA256SUMS.txt missing/stale expected line: {line}")
        for line in stale:
            issues.append(f"SHA256SUMS.txt has unexpected line: {line}")

    if issues:
        print("\nIssues:")
        for issue in issues:
            print(f"  - {issue}")
        return 1

    print("\nAudit passed.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=".", type=Path, help="Repository root")
    parser.add_argument("--write-sha256", action="store_true", help="Rewrite SHA256SUMS.txt")
    args = parser.parse_args()
    return audit(args.root.resolve(), args.write_sha256)


if __name__ == "__main__":
    raise SystemExit(main())
