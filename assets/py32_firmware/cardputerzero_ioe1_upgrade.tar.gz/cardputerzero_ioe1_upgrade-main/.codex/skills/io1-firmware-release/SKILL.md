---
name: io1-firmware-release
description: Update CardputerZero IOE1/PY32 firmware release documentation and checksums after adding or replacing bundled firmware files in cardputerzero_ioe1_upgrade. Use when Codex is asked to add a new firmware version, update README entries for firmwares/*.h, refresh SHA256SUMS.txt, verify upgrade_io1.py firmware parsing, or prepare this repository for another IOE1 firmware release.
---

# IO1 Firmware Release

## Overview

Keep the CardputerZero IOE1 upgrade repository consistent whenever bundled firmware changes. Prefer the repo's existing naming and documentation style; make narrow edits to README files and checksum metadata.

## Workflow

1. Inspect the repository from its root. Confirm `upgrade_io1.py`, `README.md`, `firmwares/README.md`, `SHA256SUMS.txt`, and `firmwares/*.h` are present.
2. List firmware files with `find firmwares -maxdepth 1 -type f -name '*.h' -print | sort`.
3. Derive each firmware's CP0 minor version from the filename suffix, such as `_0xF3.h`. Do not assume only one new firmware exists.
4. Parse or verify each header with `python3 ./upgrade_io1.py -f "<firmware>" --firmware-only`.
5. Update `README.md` and `firmwares/README.md` so all bundled firmware files, suffix lists, command examples, and `0xBA` verification notes include the new version.
6. Regenerate `SHA256SUMS.txt` for `upgrade_io1.py` and all `firmwares/*.h` files, sorted by path.
7. Run validation commands and fix any misses before responding.

## Repository Conventions

- Default firmware remains `app_without_flash_Z_12MHZ(0x4F~0x50)_0xF0.h` unless the user explicitly asks to change it.
- Firmware names currently encode: APP-only image, software version `Z`, `12MHZ`, APP address hint `0x4F~0x50`, and CP0 minor version suffix.
- `0x02` is the software-version register and should read `0x5A` for `Z`.
- `0xBA` is the CP0 minor-version register and should match the filename suffix.
- Filenames contain parentheses, so shell examples must quote `-f` paths.
- Keep `README.md` primarily Chinese and `firmwares/README.md` primarily English, matching the existing project style.

## Audit Script

Use `scripts/audit_firmware_release.py` from the skill directory to catch omissions:

```bash
python3 .codex/skills/io1-firmware-release/scripts/audit_firmware_release.py .
```

To refresh checksums deterministically:

```bash
python3 .codex/skills/io1-firmware-release/scripts/audit_firmware_release.py . --write-sha256
```

## Validation

Run these before finishing:

```bash
python3 ./upgrade_io1.py --firmware-only
for f in firmwares/*.h; do python3 ./upgrade_io1.py -f "$f" --firmware-only || exit 1; done
sha256sum -c SHA256SUMS.txt 2>/dev/null || shasum -a 256 -c SHA256SUMS.txt
python3 .codex/skills/io1-firmware-release/scripts/audit_firmware_release.py .
```

If `sha256sum` is unavailable on macOS, use `shasum -a 256` for generation and verification.
