# CardputerZero IOE1 Upgrade

这个仓库用于在 Linux 设备上通过 I2C 升级 CardputerZero / IOE1 / PY32 固件。

脚本已按 CoreMP135 测试环境整理：

- I2C 总线：`/dev/i2c-1`
- APP 地址：`0x4F`
- Bootloader 地址：`0x5F`
- 版本寄存器：`0x02`
- 示例固件版本：`Z`
- CP0 软件小版本寄存器：`0xBA`，当前包含 `0xF0` / `0xF1` / `0xF2` / `0xF3` / `0xF4` / `0xF5` / `0xF6` / `0xF7` / `0xF8` 九个固件
- `0xF4`-`0xF7` 是 `24MHZ` 固件，`0xF8` 是 `48MHZ` 固件，APP 默认 I2C 速率为 400 kHz；旧 `0xF0`-`0xF3` 的 `12MHZ` 固件不支持默认 400 kHz

`upgrade_io1.py` 只使用 Python 标准库，通过 Linux `I2C_RDWR` ioctl 访问 `/dev/i2c-*`，不依赖 `smbus2`。

## 仓库内容

```text
.
├── upgrade_io1.py
├── firmwares/
│   ├── app_without_flash_Z_12MHZ(0x4F~0x50)_0xF0.h
│   ├── app_without_flash_Z_12MHZ(0x4F~0x50)_0xF1.h
│   ├── app_without_flash_Z_12MHZ(0x4F~0x50)_0xF2.h
│   ├── app_without_flash_Z_12MHZ(0x4F~0x50)_0xF3.h
│   ├── app_without_flash_Z_24MHZ(0x4F~0x50)_0xF4.h
│   ├── app_without_flash_Z_24MHZ(0x4F~0x50)_0xF5.h
│   ├── app_without_flash_Z_24MHZ(0x4F~0x50)_0xF6.h
│   ├── app_without_flash_Z_24MHZ(0x4F~0x50)_0xF7.h
│   ├── app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h
│   └── README.md
├── SHA256SUMS.txt
└── README.md
```

当前内置固件：

```text
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF0.h  CP0 小版本 0xF0 固件
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF1.h  CP0 小版本 0xF1 固件
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF2.h  CP0 小版本 0xF2 固件
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF3.h  CP0 小版本 0xF3 固件
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF4.h  CP0 小版本 0xF4 固件，24 MHz，默认 400 kHz I2C
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF5.h  CP0 小版本 0xF5 固件，24 MHz，默认 400 kHz I2C
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF6.h  CP0 小版本 0xF6 固件，24 MHz，默认 400 kHz I2C
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF7.h  CP0 小版本 0xF7 固件，24 MHz，默认 400 kHz I2C
app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h  CP0 小版本 0xF8 固件，48 MHz，默认 400 kHz I2C
```

文件名含义：

```text
app_without_flash    APP 固件，不包含 bootloader / flash loader
Z                    软件版本，版本寄存器 0x02 预期读出 0x5A
12MHZ / 24MHZ / 48MHZ
                     12 MHz、24 MHz 或 48 MHz 版本；0xF4-0xF7 为 24MHZ，0xF8 为 48MHZ，默认 400 kHz I2C
0x4F~0x50            固件支持的 APP I2C 地址范围提示
0xF0 / 0xF1 / 0xF2 / 0xF3 / 0xF4 / 0xF5 / 0xF6 / 0xF7 / 0xF8
                     CP0_MINOR_VERSION(0xBA) 预期值；不同文件名对应不同小版本
```

注意：文件名里有括号，命令行里手动指定 `-f` 时请给路径加引号。

I2C 速率注意：`0xF4`-`0xF7` / `24MHZ` 和 `0xF8` / `48MHZ` 固件运行后默认使用 400 kHz。旧 `0xF0`-`0xF3` 固件不支持默认 400 kHz；如果当前设备仍在旧固件，升级触发和 `--dry-run` 阶段请使用旧固件可通信的 I2C 速率，刷入 `0xF4`-`0xF8` 后再按 400 kHz 使用。

## Linux 设备准备

确认 Linux 上有 Python3 和 I2C 设备：

```bash
python3 --version
ls -l /dev/i2c-*
```

确认 IOE1 当前地址。CoreMP135 实测使用 `/dev/i2c-1`：

```bash
i2cdetect -y 1 0x4f 0x50
i2cdetect -y 1 0x5f 0x5f
```

常见状态：

```text
0x4F 或 0x50 存在，0x5F 不存在：IOE1 正常 APP 模式
0x4F/0x50 不存在，0x5F 存在：IOE1 在 bootloader 模式
都不存在：检查 I2C 总线号、供电、线序或是否被其他程序占用
```

脚本默认执行时不会再自动刷入 `0xF0`。未指定 `-f` 时会显示内置固件菜单，默认选项指向文件名尾部版本号最高的固件（当前为 `0xF8`）。确认固件后，脚本会先读取当前 APP 版本确认设备可通信；最后显示升级摘要时直接回车即可正式写入。

如果设备已经停在 bootloader，脚本会识别 `0x5F` 并进入恢复流程；此时 APP 当前版本无法读取，日志会明确显示这一点，并仍然要求最终确认后才写入。

如果 Linux 上没有 `i2cdetect`，安装 `i2c-tools`，或者直接用脚本 `--dry-run` 测试。

## 快速测试

进入仓库目录：

```bash
cd cardputerzero_ioe1_upgrade
```

在开发电脑上可以先检查固件头文件是否能解析，不需要连接 I2C：

```bash
python3 ./upgrade_io1.py --firmware-only
```

预期输出类似：

```text
INFO: STEP 1/7: Selecting firmware
INFO: No firmware specified; using latest bundled firmware for this check: .../firmwares/app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h
INFO: Firmware: .../firmwares/app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h (20480 bytes)
INFO: Firmware-only check enabled; no I2C device opened
INFO: RESULT: SUCCESS
```

先跑 dry-run。dry-run 会检查当前 APP 通信并读取旧版本；如果 APP 不响应，会继续探测 bootloader 恢复地址，但不会触发升级，也不会写 flash：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  --dry-run \
  -v \
  --log-file dryrun.log
```

`--dry-run` 未指定 `-f` 时会使用当前最新的内置固件做解析检查，但不会弹出正式升级菜单，也不会写入设备。当前最新固件路径是：

```text
./firmwares/app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h
```

预期输出类似：

```text
INFO: Firmware: .../firmwares/app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h (20480 bytes)
INFO: I2C: bus=/dev/i2c-1 app=0x4F new=0x4F bootloader=0x5F
INFO: STEP 2/7: Checking APP communication at addr=0x4F, software register=0x02
INFO: Current APP software version: 0x5A ('Z')
INFO: Current CP0 minor version: 0xF8
INFO: Dry run enabled; no upgrade commands sent
```

如果设备已经停在 bootloader，`--dry-run` 会显示检测到 `0x5F`，并且不会读取 APP 版本。

## 正常升级

默认交互升级。脚本会显示固件菜单，默认选中最新尾部版本号（当前 `0xF8`）；确认设备通信后，最后一步直接回车开始写 flash，按 `q` / `n` / `Esc` 会立即取消，不需要再回车：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -v \
  --log-file upgrade.log
```

如果你要刷入 `0xF0`，需要显式指定固件并确认：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_12MHZ(0x4F~0x50)_0xF0.h" \
  -v \
  --log-file upgrade_z_12mhz.log
```

`0xF1` 固件需要通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_12MHZ(0x4F~0x50)_0xF1.h" \
  -v \
  --log-file upgrade_z_12mhz_f1.log
```

新增的 `0xF2` 固件同样通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_12MHZ(0x4F~0x50)_0xF2.h" \
  -v \
  --log-file upgrade_z_12mhz_f2.log
```

新增的 `0xF3` 固件同样通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_12MHZ(0x4F~0x50)_0xF3.h" \
  -v \
  --log-file upgrade_z_12mhz_f3.log
```

新增的 `0xF4` / `24MHZ` 固件同样通过 `-f` 显式指定。这个版本 APP 默认 I2C 速率为 400 kHz，旧 `0xF0`-`0xF3` 固件不支持默认 400 kHz：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_24MHZ(0x4F~0x50)_0xF4.h" \
  -v \
  --log-file upgrade_z_24mhz_f4.log
```

新增的 `0xF5` / `24MHZ` 固件同样通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_24MHZ(0x4F~0x50)_0xF5.h" \
  -v \
  --log-file upgrade_f5.log
```

新增的 `0xF6` / `24MHZ` 固件同样通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_24MHZ(0x4F~0x50)_0xF6.h" \
  -v \
  --log-file upgrade_f6.log
```

新增的 `0xF7` / `24MHZ` 固件同样通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_24MHZ(0x4F~0x50)_0xF7.h" \
  -v \
  --log-file upgrade_f7.log
```

新增的 `0xF8` / `48MHZ` 固件同样通过 `-f` 显式指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h" \
  -v \
  --log-file upgrade_f8.log
```

升级流程：

```text
1. 未指定 -f 时显示内置固件菜单，默认选中最新尾部版本号。
2. 读取当前 APP 软件版本寄存器 0x02，并尝试读取 CP0 小版本寄存器 0xBA。
3. 如果 APP 不响应，探测 bootloader 地址 0x5F；检测到 bootloader 时进入恢复流程。
4. 显示最终升级摘要，直接回车继续写入；按 q / n / Esc 会立即取消，不需要再回车。
5. 写 APP 触发寄存器 0xFD = 0x1A，或在 bootloader 恢复流程中跳过触发。
6. 等待设备切换到 bootloader 地址 0x5F，并发送写使能命令 0x06。
7. 分页写入固件。
8. 发送跳回 APP 命令 0x77。
9. 读取新 APP 版本和 CP0 小版本，日志显示成功或失败结果后退出脚本。
```

升级完成后，可以用你的测试固件或 I2C 工具确认：

```text
0x02 = 0x5A ('Z')
0xBA = 0xF0   # 使用 F0 固件时
0xBA = 0xF1   # 使用 F1 固件时
0xBA = 0xF2   # 使用 F2 固件时
0xBA = 0xF3   # 使用新增 F3 固件时
0xBA = 0xF4   # 使用新增 F4 / 24MHz / 默认 400 kHz 固件时
0xBA = 0xF5   # 使用新增 F5 固件时
0xBA = 0xF6   # 使用新增 F6 固件时
0xBA = 0xF7   # 使用新增 F7 固件时
0xBA = 0xF8   # 使用新增 F8 固件时
```

## 升级前后 I2C 地址

脚本不会自动从固件内容里识别升级前后的 APP 地址，而是通过参数区分：

```text
--old-app-address       升级前 APP 地址，默认 0x4F
--bootloader-address    升级过程中的 bootloader 地址，默认 0x5F
--new-app-address       升级后 APP 地址，默认 0x4F
```

完整地址流程：

```text
1. 用 old-app-address 读取旧版本。
2. 用 old-app-address 写触发寄存器 0xFD = 0x1A。
3. 等 IOE1 切到 bootloader-address，默认 0x5F。
4. 通过 bootloader-address 写固件。
5. 发送跳回 APP 命令。
6. 用 new-app-address 读取升级后版本。
```

重点：`--new-app-address` 只告诉脚本“升级完成后去哪个地址读版本验证”，它不会修改固件里的 I2C 地址。实际升级后的 APP 地址由固件本身决定。

当前示例固件文件名标注 `0x4F~0x50`。如果你的板子升级前在 `0x4F`，升级后也按 `0x4F` 验证：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  --old-app-address 0x4F \
  --new-app-address 0x4F \
  -v \
  --log-file upgrade_4f.log
```

如果你的板子升级后实际响应在 `0x50`，把 `--new-app-address` 改成 `0x50`：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  --old-app-address 0x4F \
  --new-app-address 0x50 \
  -v \
  --log-file upgrade_4f_to_50.log
```

如果升级后读版本失败，先扫描：

```bash
i2cdetect -y 1 0x4f 0x50
```

扫描到哪个地址，就把下次命令里的 `--old-app-address` 或 `--new-app-address` 改成哪个地址。

## Bootloader 恢复

如果升级中断，APP 地址不响应，但 `0x5F` 响应：

```bash
i2cdetect -y 1 0x5f 0x5f
```

现在普通升级命令会自动识别这个状态并直接通过 bootloader 写固件，不需要额外参数：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -v \
  --log-file recover_z_12mhz.log
```

`--already-in-bootloader` 仍然保留，用于你已经确认设备在 bootloader、并希望跳过自动探测时使用：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  --already-in-bootloader \
  -v \
  --log-file recover_z_12mhz.log
```

## 使用其他固件

把新的 `.h` 或 `.bin` 放到 `firmwares/` 后，通过 `-f` 指定：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -f "./firmwares/your_firmware.h" \
  --old-app-address 0x4F \
  --new-app-address 0x4F \
  -v \
  --log-file upgrade_custom.log
```

如果新固件改变了 APP 地址，务必同步修改 `--new-app-address`。如果当前设备已经运行在新地址，下一次升级时也要同步修改 `--old-app-address`。

## 日志

默认输出关键步骤：

```bash
python3 ./upgrade_io1.py -b /dev/i2c-1
```

打开详细 I2C 日志：

```bash
python3 ./upgrade_io1.py -b /dev/i2c-1 -v
```

保存完整日志：

```bash
python3 ./upgrade_io1.py \
  -b /dev/i2c-1 \
  -v \
  --log-file upgrade.log
```

查看日志：

```bash
tail -n 80 upgrade.log
```

## 校验文件

仓库提供 `SHA256SUMS.txt`，复制到 Linux 后可校验文件是否完整：

```bash
sha256sum -c SHA256SUMS.txt
```

如果 Linux 不支持 `sha256sum -c`，可以分别执行：

```bash
sha256sum upgrade_io1.py firmwares/*.h
```

## 常用参数

```text
-b, --bus                 Linux I2C 设备，默认 /dev/i2c-1
-f, --firmware            固件 .h 或 .bin 文件；不指定时，正式升级会显示固件菜单，默认选中最新尾部版本号
--old-app-address         当前 APP I2C 地址，默认 0x4F
--new-app-address         升级后 APP I2C 地址，默认 0x4F
--bootloader-address      Bootloader I2C 地址，默认 0x5F
--version-register        软件版本寄存器，默认 0x02
--cp0-minor-register      CP0 小版本寄存器，默认 0xBA
--trigger-register        触发升级寄存器，默认 0xFD
--trigger-value           触发升级值，默认 0x1A
--application-address     PY32 APP flash 地址，默认 0x08001000
--page-size               每页写入大小，默认 128
--dry-run                 只读版本，不写固件
--firmware-only           只解析固件，不打开 I2C
--already-in-bootloader   IOE1 已在 bootloader 时强制跳过自动探测和 APP 触发；通常不需要
-v, --verbose             打印详细 I2C 调试日志
--log-file                保存完整日志到文件
```

## 常见问题

`/dev/i2c-1` 不存在：

```bash
ls -l /dev/i2c-*
```

根据实际总线修改 `-b`，例如：

```bash
python3 ./upgrade_io1.py -b /dev/i2c-0 --dry-run
```

`0x4F` 不响应：

```bash
i2cdetect -y 1 0x4f 0x50
i2cdetect -y 1 0x5f 0x5f
```

如果 `0x5F` 存在，直接运行普通升级命令即可自动恢复。如果 `0x50` 存在，把脚本地址参数改成 `0x50`。

升级过程中超时：

- 确认供电稳定。
- 确认 I2C 总线没有被其他程序占用。
- 保留 `--log-file` 日志，优先看最后 50 行。

```bash
tail -n 50 upgrade.log
```

## 安全建议

- 正式写固件前先跑 `--dry-run`。
- 升级期间不要断电。
- 每次升级都带 `--log-file`，方便回溯。
- 切换不同地址版本前，先确认 `i2cdetect` 能扫描到当前设备。
