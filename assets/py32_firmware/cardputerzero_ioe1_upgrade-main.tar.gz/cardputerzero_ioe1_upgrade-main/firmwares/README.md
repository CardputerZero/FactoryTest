# Firmware Files

This directory contains IOE1/PY32 application firmware images.

Current bundled firmware files:

```text
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF0.h  CP0 minor-version 0xF0 sample
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF1.h  CP0 minor-version 0xF1 sample
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF2.h  CP0 minor-version 0xF2 sample
app_without_flash_Z_12MHZ(0x4F~0x50)_0xF3.h  CP0 minor-version 0xF3 sample
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF4.h  CP0 minor-version 0xF4 sample, 24 MHz, default 400 kHz I2C
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF5.h  CP0 minor-version 0xF5 sample, 24 MHz, default 400 kHz I2C
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF6.h  CP0 minor-version 0xF6 sample, 24 MHz, default 400 kHz I2C
app_without_flash_Z_24MHZ(0x4F~0x50)_0xF7.h  CP0 minor-version 0xF7 sample, 24 MHz, default 400 kHz I2C
app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h  CP0 minor-version 0xF8 sample, 48 MHz, default 400 kHz I2C
```

Meaning:

```text
app_without_flash    Application image only
Z                    Software version, register 0x02 should read 0x5A
12MHZ / 24MHZ / 48MHZ
                     12 MHz, 24 MHz, or 48 MHz build; 0xF4-0xF7 are 24MHZ, 0xF8 is 48MHZ, and these default to 400 kHz I2C
0x4F~0x50            Expected APP I2C address range
0xF0 / 0xF1 / 0xF2 / 0xF3 / 0xF4 / 0xF5 / 0xF6 / 0xF7 / 0xF8
                     CP0_MINOR_VERSION register 0xBA should match the filename suffix
```

I2C speed note: `0xF4`-`0xF7` / `24MHZ` and `0xF8` / `48MHZ` default to 400 kHz I2C after running. Older `0xF0`-`0xF3` / `12MHZ` firmware cannot be used as a default-400 kHz target, so trigger or dry-run an old device at a speed it can still answer before upgrading to `0xF4`-`0xF8`.

The header contains:

```c
unsigned long appHexLength = 0x5000;
static const unsigned char appHexData[] = { ... };
```

`upgrade_io1.py` can parse these `.h` files directly. It also accepts raw `.bin` files through `-f`.

When `upgrade_io1.py` runs in normal upgrade mode without `-f`, it shows a firmware menu. The default menu item is the bundled firmware with the highest filename suffix, which is currently `0xF8`.

Because these filenames contain parentheses, quote the path when using one in a shell:

```bash
python3 ../upgrade_io1.py -f "./app_without_flash_Z_48MHZ(0x4F~0x50)_0xF8.h"
```
