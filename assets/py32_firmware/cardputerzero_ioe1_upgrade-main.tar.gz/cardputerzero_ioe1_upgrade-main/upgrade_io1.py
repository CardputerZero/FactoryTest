#!/usr/bin/env python3
"""Upgrade IO1/PY32 firmware over Linux I2C.

Typical use on the Linux device:
  sudo python3 ./upgrade_io1.py -b /dev/i2c-1

Without -f, the script shows a bundled firmware menu. The default menu item is
the highest CP0 minor-version suffix in firmwares/*.h, such as _0xF4.h.

If the previous attempt left IO1 in bootloader mode, the same command auto-detects it:
  sudo python3 ./upgrade_io1.py -b /dev/i2c-1

Use a raw binary instead of the bundled header firmware:
  sudo python3 ./upgrade_io1.py -b /dev/i2c-1 -f io1_app.bin

Check the bundled firmware file on a development machine without I2C:
  python3 ./upgrade_io1.py --firmware-only

This script mirrors the Arduino IOExpanderIAP flow with two confirmations:
  1. Select and confirm firmware.
  2. Read the current app version from app address, or detect bootloader recovery.
  3. Show a final summary; press Enter to confirm flashing, or press q/n/Esc to abort.
  4. Write trigger register 0xFD = 0x1A if app mode is active.
  5. Wait for bootloader address 0x5F.
  6. Send write-enable command 0x06.
  7. Write firmware pages.
  8. Send jump-to-application command 0x77.
  9. Read new app version and CP0 minor version.
"""

from __future__ import annotations

import argparse
import array
from dataclasses import dataclass
import logging
import os
import re
import struct
import sys
import time
from pathlib import Path


class RawDefaultsHelpFormatter(
    argparse.ArgumentDefaultsHelpFormatter,
    argparse.RawDescriptionHelpFormatter,
):
    def _expand_help(self, action):
        params = dict(vars(action), prog=self._prog)
        for name in list(params):
            if params[name] is argparse.SUPPRESS:
                del params[name]
            elif hasattr(params[name], "__name__"):
                params[name] = params[name].__name__

        hex_default_dests = {
            "old_app_address",
            "new_app_address",
            "bootloader_address",
            "version_register",
            "cp0_minor_register",
            "trigger_register",
            "trigger_value",
            "application_address",
        }
        if action.dest in hex_default_dests and isinstance(action.default, int):
            width = 8 if action.default > 0xFFFF else 2
            params["default"] = f"0x{action.default:0{width}X}"

        if params.get("choices") is not None:
            params["choices"] = ", ".join(map(str, params["choices"]))

        return self._get_help_string(action) % params


I2C_RDWR = 0x0707
I2C_M_RD = 0x0001

DEFAULT_APP_ADDRESS = 0x4F
DEFAULT_BOOTLOADER_ADDRESS = 0x5F
DEFAULT_VERSION_REGISTER = 0x02
DEFAULT_TRIGGER_REGISTER = 0xFD
DEFAULT_TRIGGER_VALUE = 0x1A
DEFAULT_APPLICATION_ADDRESS = 0x08001000
DEFAULT_PAGE_SIZE = 128
DEFAULT_PAGE_WRITE_RETRIES = 5
DEFAULT_CP0_MINOR_REGISTER = 0xBA

OPC_WREN = 0x06
OPC_USRCD = 0x77

SCRIPT_DIR = Path(__file__).resolve().parent
FIRMWARE_DIR = SCRIPT_DIR / "firmwares"
FIRMWARE_SUFFIX_RE = re.compile(r"_(0x[0-9a-fA-F]+)\.(?:h|hpp)$")

LOGGER = logging.getLogger("upgrade_io1")


class I2CError(RuntimeError):
    pass


class UserCancelled(RuntimeError):
    pass


@dataclass(frozen=True)
class FirmwareChoice:
    path: Path
    minor: int | None
    clock: str | None
    length: int | None


@dataclass(frozen=True)
class DeviceState:
    in_bootloader: bool
    old_sw_version: int | None
    old_cp0_minor: int | None


class LinuxI2C:
    def __init__(self, device: str):
        try:
            import fcntl
        except ImportError as exc:
            raise RuntimeError("Linux I2C access requires the standard-library fcntl module; run this on Linux") from exc

        self.device = device
        self._fcntl = fcntl
        self.fd = os.open(device, os.O_RDWR)
        LOGGER.debug("Opened I2C device %s fd=%d", device, self.fd)

    def close(self) -> None:
        os.close(self.fd)
        LOGGER.debug("Closed I2C device %s", self.device)

    def __enter__(self) -> "LinuxI2C":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def write(self, address: int, data: bytes | bytearray) -> None:
        if not data:
            raise ValueError("i2c write data is empty")
        LOGGER.debug("I2C write addr=0x%02X len=%d data=%s", address, len(data), bytes(data).hex(" "))
        self.transfer([(address, 0, bytes(data))])

    def read_register(self, address: int, register: int, length: int = 1) -> bytes:
        LOGGER.debug("I2C read addr=0x%02X reg=0x%02X len=%d", address, register, length)
        read_buffer = bytearray(length)
        self.transfer(
            [
                (address, 0, bytes([register])),
                (address, I2C_M_RD, read_buffer),
            ]
        )
        data = bytes(read_buffer)
        LOGGER.debug("I2C read result addr=0x%02X reg=0x%02X data=%s", address, register, data.hex(" "))
        return data

    def write_register(self, address: int, register: int, data: bytes | bytearray) -> None:
        LOGGER.debug("I2C write reg addr=0x%02X reg=0x%02X data=%s", address, register, bytes(data).hex(" "))
        self.write(address, bytes([register]) + bytes(data))

    def probe(self, address: int) -> bool:
        try:
            self.transfer([(address, 0, b"")])
            return True
        except OSError:
            return False
        except I2CError:
            return False

    def transfer(self, messages: list[tuple[int, int, bytes | bytearray]]) -> None:
        msg_buffers = []
        msg_structs = []
        mutable_targets = []

        for address, flags, data in messages:
            if isinstance(data, bytes):
                buffer = array.array("B", data)
                mutable_targets.append(None)
            else:
                buffer = array.array("B", data)
                mutable_targets.append(data)
            msg_buffers.append(buffer)
            msg_structs.append(
                struct.pack("HHHP", address, flags, len(buffer), buffer.buffer_info()[0])
            )

        msg_array = array.array("B", b"".join(msg_structs))
        if struct.calcsize("P") == 8:
            ioctl_data = struct.pack("PI4x", msg_array.buffer_info()[0], len(messages))
        else:
            ioctl_data = struct.pack("PI", msg_array.buffer_info()[0], len(messages))

        try:
            self._fcntl.ioctl(self.fd, I2C_RDWR, ioctl_data)
        except OSError as exc:
            raise I2CError(str(exc)) from exc

        for target, buffer in zip(mutable_targets, msg_buffers):
            if target is not None:
                target[:] = buffer.tobytes()


def parse_int(value: str) -> int:
    return int(value, 0)


def parse_firmware_header(path: Path) -> bytes:
    LOGGER.debug("Parsing firmware header: %s", path)
    text = path.read_text(encoding="utf-8", errors="ignore")

    length_match = re.search(r"\bappHexLength\s*=\s*(0x[0-9a-fA-F]+|\d+)", text)
    if not length_match:
        raise ValueError(f"Cannot find appHexLength in {path}")
    expected_length = int(length_match.group(1), 0)

    array_match = re.search(r"\bappHexData\s*\[\]\s*=\s*\{(?P<body>.*?)\};", text, re.S)
    if not array_match:
        raise ValueError(f"Cannot find appHexData array in {path}")

    values = [int(item, 16) for item in re.findall(r"0x([0-9a-fA-F]{1,2})", array_match.group("body"))]
    firmware = bytes(values)

    if len(firmware) != expected_length:
        raise ValueError(
            f"Firmware length mismatch: header says {expected_length}, parsed {len(firmware)}"
        )

    return firmware


def parse_firmware_length(path: Path) -> int | None:
    if path.suffix.lower() not in {".h", ".hpp"}:
        try:
            return path.stat().st_size
        except OSError:
            return None

    text = path.read_text(encoding="utf-8", errors="ignore")
    length_match = re.search(r"\bappHexLength\s*=\s*(0x[0-9a-fA-F]+|\d+)", text)
    return int(length_match.group(1), 0) if length_match else None


def load_firmware(path: Path) -> bytes:
    LOGGER.debug("Loading firmware: %s", path)
    if path.suffix.lower() in {".h", ".hpp"}:
        return parse_firmware_header(path)
    return path.read_bytes()


def firmware_minor_from_name(path: Path) -> int | None:
    match = FIRMWARE_SUFFIX_RE.search(path.name)
    return int(match.group(1), 16) if match else None


def firmware_clock_from_name(path: Path) -> str | None:
    match = re.search(r"_([0-9]+MHZ)\(", path.name, re.IGNORECASE)
    return match.group(1).upper() if match else None


def discover_bundled_firmwares() -> list[FirmwareChoice]:
    choices = []
    for path in sorted(FIRMWARE_DIR.glob("*.h")):
        choices.append(
            FirmwareChoice(
                path=path,
                minor=firmware_minor_from_name(path),
                clock=firmware_clock_from_name(path),
                length=parse_firmware_length(path),
            )
        )
    return choices


def latest_firmware_choice(choices: list[FirmwareChoice]) -> FirmwareChoice:
    if not choices:
        raise FileNotFoundError(f"No bundled firmware headers found in {FIRMWARE_DIR}")

    def sort_key(choice: FirmwareChoice) -> tuple[int, str]:
        return (-1 if choice.minor is None else choice.minor, choice.path.name)

    return max(choices, key=sort_key)


def format_size(length: int | None) -> str:
    return "unknown size" if length is None else f"{length} bytes"


def format_minor(minor: int | None) -> str:
    return "unknown" if minor is None else f"0x{minor:02X}"


def format_sw_version(value: int | None) -> str:
    if value is None:
        return "unavailable"
    if 32 <= value <= 126:
        return f"0x{value:02X} ({chr(value)!r})"
    return f"0x{value:02X}"


def format_firmware_choice(choice: FirmwareChoice) -> str:
    parts = [
        choice.path.name,
        f"CP0={format_minor(choice.minor)}",
        choice.clock or "clock=unknown",
        format_size(choice.length),
    ]
    return ", ".join(parts)


def prompt_line(prompt: str) -> str:
    try:
        return input(prompt)
    except EOFError as exc:
        raise RuntimeError("Interactive input is required for firmware selection or upgrade confirmation") from exc


def read_single_key(prompt: str) -> str:
    if not sys.stdin.isatty():
        answer = prompt_line(prompt)
        return "\n" if answer == "" else answer[0]

    print(prompt, end="", flush=True)
    try:
        if os.name == "nt":
            import msvcrt

            key = msvcrt.getwch()
        else:
            import termios
            import tty

            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                key = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    except ImportError as exc:
        raise RuntimeError("Single-key confirmation requires a terminal supported by the Python standard library") from exc
    finally:
        print()

    if key == "\x03":
        raise KeyboardInterrupt

    return key


def is_enter_key(key: str) -> bool:
    return key in {"\r", "\n"}


def is_abort_key(key: str) -> bool:
    return key == "\x1b" or key.lower() in {"q", "n"}


def prompt_yes_no(prompt: str, default: bool = False) -> bool:
    suffix = " [Enter/y=yes, q/n/Esc=no]: " if default else " [y=yes, Enter/q/n/Esc=no]: "
    while True:
        key = read_single_key(prompt + suffix)
        if is_enter_key(key):
            return default
        if is_abort_key(key):
            return False
        if key.lower() == "y":
            return True
        print("Please press Enter, y, q, n, or Esc.")


def prompt_menu_key(default_index: int, max_index: int) -> str:
    return read_single_key(f"Select firmware [{default_index}] (1-{max_index}, Enter=default, q/n/Esc=abort): ")


def prompt_final_confirmation() -> None:
    key = read_single_key("Press Enter to start flashing, or press q/n/Esc to abort: ")
    if is_enter_key(key):
        return
    if is_abort_key(key):
        raise UserCancelled("User aborted before firmware write")
    raise UserCancelled("Unexpected key; firmware write was not started")


def select_firmware_from_menu(choices: list[FirmwareChoice]) -> FirmwareChoice:
    default_choice = latest_firmware_choice(choices)
    default_index = choices.index(default_choice) + 1

    print()
    print("Bundled firmware menu")
    print("---------------------")
    for index, choice in enumerate(choices, start=1):
        marker = " (default/latest)" if index == default_index else ""
        print(f"{index}. {format_firmware_choice(choice)}{marker}")
    print("q/n/Esc. Abort")
    print()

    while True:
        key = prompt_menu_key(default_index, len(choices))
        if is_enter_key(key):
            LOGGER.info("Firmware menu default selected: %s", default_choice.path)
            return default_choice
        if is_abort_key(key):
            raise UserCancelled("User aborted at firmware menu")
        if not key.isdigit():
            print("Please press a firmware number, Enter, q, n, or Esc.")
            continue
        selected_index = int(key, 10)
        if 1 <= selected_index <= len(choices):
            choice = choices[selected_index - 1]
            LOGGER.info("Firmware menu selected: %s", choice.path)
            return choice
        print(f"Please press a number from 1 to {len(choices)}, Enter, q, n, or Esc.")


def resolve_firmware_path(args: argparse.Namespace) -> Path:
    if args.firmware is not None:
        args.firmware = args.firmware.expanduser()
        if not args.firmware.exists():
            raise FileNotFoundError(f"Firmware file not found: {args.firmware}")
        choice = FirmwareChoice(
            path=args.firmware,
            minor=firmware_minor_from_name(args.firmware),
            clock=firmware_clock_from_name(args.firmware),
            length=parse_firmware_length(args.firmware),
        )
        LOGGER.info("Firmware specified on command line: %s", format_firmware_choice(choice))
        if not args.firmware_only and not args.dry_run:
            if not prompt_yes_no("Confirm this firmware file?", default=True):
                raise UserCancelled("User aborted firmware selection")
        return args.firmware

    choices = discover_bundled_firmwares()
    if args.firmware_only or args.dry_run:
        choice = latest_firmware_choice(choices)
        LOGGER.info("No firmware specified; using latest bundled firmware for this check: %s", choice.path)
        return choice.path

    return select_firmware_from_menu(choices).path


def read_version(bus: LinuxI2C, address: int, register: int) -> int:
    return bus.read_register(address, register, 1)[0]


def wait_for_address(bus: LinuxI2C, address: int, present: bool, timeout_s: float, poll_s: float) -> bool:
    LOGGER.debug(
        "Waiting for addr=0x%02X present=%s timeout=%.2fs poll=%.2fs",
        address,
        present,
        timeout_s,
        poll_s,
    )
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if bus.probe(address) == present:
            LOGGER.debug("Address 0x%02X reached present=%s", address, present)
            return True
        time.sleep(poll_s)
    LOGGER.debug("Timeout waiting for addr=0x%02X present=%s", address, present)
    return False


def write_command_with_retries(
    bus: LinuxI2C,
    address: int,
    data: bytes,
    retries: int,
    retry_delay_s: float,
    description: str,
) -> None:
    for attempt in range(retries + 1):
        try:
            bus.write(address, data)
            return
        except I2CError as exc:
            if attempt >= retries:
                raise
            LOGGER.warning(
                "%s failed (attempt %d/%d): %s; retrying",
                description,
                attempt + 1,
                retries + 1,
                exc,
            )
            time.sleep(retry_delay_s)


def inspect_device(bus: LinuxI2C, args: argparse.Namespace) -> DeviceState:
    if args.already_in_bootloader:
        LOGGER.info("STEP 2/7: Checking requested bootloader address 0x%02X", args.bootloader_address)
        if not bus.probe(args.bootloader_address):
            raise RuntimeError(f"Bootloader 0x{args.bootloader_address:02X} does not respond")
        LOGGER.info("Bootloader communication OK at 0x%02X", args.bootloader_address)
        LOGGER.warning("Current APP version is unavailable because the device is already in bootloader mode")
        return DeviceState(in_bootloader=True, old_sw_version=None, old_cp0_minor=None)

    if args.skip_old_version:
        LOGGER.warning("--skip-old-version is ignored before flashing; current APP communication must be checked")

    LOGGER.info(
        "STEP 2/7: Checking APP communication at addr=0x%02X, software register=0x%02X",
        args.old_app_address,
        args.version_register,
    )

    try:
        old_sw_version = read_version(bus, args.old_app_address, args.version_register)
    except Exception as app_exc:
        LOGGER.warning(
            "Cannot read current APP software version at addr=0x%02X reg=0x%02X: %s",
            args.old_app_address,
            args.version_register,
            app_exc,
        )
        LOGGER.info("Checking bootloader recovery address 0x%02X", args.bootloader_address)
        if bus.probe(args.bootloader_address):
            LOGGER.warning("Bootloader responds at 0x%02X; APP version is unavailable", args.bootloader_address)
            return DeviceState(in_bootloader=True, old_sw_version=None, old_cp0_minor=None)
        raise RuntimeError(
            "Device is not reachable: cannot read APP version and bootloader does not respond"
        ) from app_exc

    LOGGER.info("Current APP software version: %s", format_sw_version(old_sw_version))

    old_cp0_minor = None
    try:
        old_cp0_minor = read_version(bus, args.old_app_address, args.cp0_minor_register)
        LOGGER.info("Current CP0 minor version: 0x%02X", old_cp0_minor)
    except Exception as minor_exc:
        LOGGER.warning(
            "APP communication is OK, but CP0 minor register 0x%02X could not be read: %s",
            args.cp0_minor_register,
            minor_exc,
        )

    return DeviceState(
        in_bootloader=False,
        old_sw_version=old_sw_version,
        old_cp0_minor=old_cp0_minor,
    )


def confirm_upgrade_start(args: argparse.Namespace, firmware: bytes, state: DeviceState) -> None:
    print()
    print("Final upgrade confirmation")
    print("--------------------------")
    print(f"Firmware: {args.firmware}")
    print(f"Firmware size: {len(firmware)} bytes")
    print(f"I2C bus: {args.bus}")
    print(f"APP address before upgrade: 0x{args.old_app_address:02X}")
    print(f"APP address after upgrade:  0x{args.new_app_address:02X}")
    print(f"Bootloader address:        0x{args.bootloader_address:02X}")
    if state.in_bootloader:
        print("Current state: bootloader mode; APP version unavailable")
    else:
        print(f"Current software version:  {format_sw_version(state.old_sw_version)}")
        print(f"Current CP0 minor:         {format_minor(state.old_cp0_minor)}")
    print()

    prompt_final_confirmation()
    LOGGER.info("Final confirmation received; starting firmware write")


def write_firmware(
    bus: LinuxI2C,
    firmware: bytes,
    bootloader_address: int,
    application_address: int,
    page_size: int,
    ready_timeout_s: float,
    poll_s: float,
    page_delay_s: float,
    page_write_retries: int,
) -> None:
    if not firmware:
        raise ValueError("firmware is empty")
    if page_size <= 0 or page_size > 240:
        raise ValueError("page size must be 1..240")
    if page_write_retries < 0:
        raise ValueError("page write retries must be >= 0")

    total = len(firmware)
    written = 0
    address = application_address
    last_percent = -1
    last_logged_percent = -10

    LOGGER.info(
        "Writing firmware to 0x%08X, total=%d bytes, page=%d bytes",
        application_address,
        total,
        page_size,
    )

    while written < total:
        chunk = firmware[written : written + page_size]
        data_len = len(chunk)
        packet = bytes(
            [
                OPC_WREN,
                (address >> 24) & 0xFF,
                (address >> 16) & 0xFF,
                (address >> 8) & 0xFF,
                address & 0xFF,
                0x00,
                data_len & 0xFF,
                0xFF,
            ]
        ) + chunk

        for attempt in range(page_write_retries + 1):
            if not wait_for_address(bus, bootloader_address, True, ready_timeout_s, poll_s):
                error = TimeoutError(f"Bootloader 0x{bootloader_address:02X} not ready")
            else:
                try:
                    bus.write(bootloader_address, packet)
                    break
                except I2CError as exc:
                    error = exc

            if attempt >= page_write_retries:
                raise error

            LOGGER.warning(
                "Page write failed at address 0x%08X (attempt %d/%d): %s; retrying",
                address,
                attempt + 1,
                page_write_retries + 1,
                error,
            )
            time.sleep(max(page_delay_s, poll_s))

        written += data_len
        address += data_len

        percent = int((written * 100) / total)
        if percent != last_percent:
            print(f"\rWriting firmware: {written}/{total} bytes {percent:3d}%", end="", flush=True)
            last_percent = percent

        if percent == 100 or percent - last_logged_percent >= 10:
            LOGGER.info("Firmware progress: %d/%d bytes %d%%", written, total, percent)
            last_logged_percent = percent

        time.sleep(page_delay_s)

    print()
    LOGGER.info("Firmware write finished")


def jump_to_application(bus: LinuxI2C, bootloader_address: int, exit_timeout_s: float, poll_s: float) -> None:
    LOGGER.info("Jumping to application from bootloader 0x%02X", bootloader_address)
    deadline = time.monotonic() + exit_timeout_s
    while time.monotonic() < deadline:
        try:
            bus.write(bootloader_address, bytes([OPC_USRCD]))
        except I2CError:
            LOGGER.debug("Jump command write failed, retrying", exc_info=True)
            pass
        time.sleep(poll_s)
        if not bus.probe(bootloader_address):
            LOGGER.info("Bootloader exited")
            return
    raise TimeoutError(f"Bootloader 0x{bootloader_address:02X} did not exit")


def setup_logging(args: argparse.Namespace) -> None:
    level = logging.DEBUG if args.verbose else logging.INFO
    logger_level = logging.DEBUG if args.verbose or args.log_file else logging.INFO

    LOGGER.handlers.clear()
    LOGGER.setLevel(logger_level)
    LOGGER.propagate = False

    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(level)
    console_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    LOGGER.addHandler(console_handler)

    if args.log_file:
        args.log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(args.log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        LOGGER.addHandler(file_handler)
        LOGGER.info("Log file: %s", args.log_file)


def upgrade(args: argparse.Namespace) -> None:
    LOGGER.info("STEP 1/7: Selecting firmware")
    args.firmware = resolve_firmware_path(args)

    firmware = load_firmware(args.firmware)
    LOGGER.info("Firmware: %s (%d bytes)", args.firmware, len(firmware))
    LOGGER.info(
        "I2C: bus={bus} app=0x{app:02X} new=0x{new:02X} bootloader=0x{boot:02X}".format(
            bus=args.bus,
            app=args.old_app_address,
            new=args.new_app_address,
            boot=args.bootloader_address,
        )
    )

    if args.firmware_only:
        LOGGER.info("Firmware-only check enabled; no I2C device opened")
        return

    LOGGER.info("Opening I2C bus %s", args.bus)
    with LinuxI2C(args.bus) as bus:
        state = inspect_device(bus, args)

        if args.dry_run:
            LOGGER.info("Dry run enabled; no upgrade commands sent")
            return

        LOGGER.info("STEP 3/7: Waiting for final user confirmation")
        confirm_upgrade_start(args, firmware, state)

        if state.in_bootloader:
            LOGGER.info("STEP 4/7: Using existing bootloader session; app trigger skipped")
        else:
            LOGGER.info(
                "STEP 4/7: Triggering upgrade mode: addr=0x%02X reg=0x%02X value=0x%02X",
                args.old_app_address,
                args.trigger_register,
                args.trigger_value,
            )
            bus.write_register(args.old_app_address, args.trigger_register, bytes([args.trigger_value]))
            time.sleep(args.post_trigger_delay)

        LOGGER.info("STEP 5/7: Waiting for bootloader at 0x%02X", args.bootloader_address)
        if not wait_for_address(
            bus,
            args.bootloader_address,
            True,
            args.enter_timeout,
            args.poll_interval,
        ):
            raise TimeoutError(f"Bootloader 0x{args.bootloader_address:02X} not found")

        LOGGER.info("Sending write-enable command")
        write_command_with_retries(
            bus,
            args.bootloader_address,
            bytes([OPC_WREN]),
            args.page_write_retries,
            max(args.page_delay, args.poll_interval),
            "Write-enable command",
        )

        LOGGER.info("STEP 6/7: Writing firmware pages")
        write_firmware(
            bus,
            firmware,
            args.bootloader_address,
            args.application_address,
            args.page_size,
            args.ready_timeout,
            args.poll_interval,
            args.page_delay,
            args.page_write_retries,
        )

        LOGGER.info("STEP 7/7: Jumping back to APP and verifying result")
        jump_to_application(
            bus,
            args.bootloader_address,
            args.exit_timeout,
            args.poll_interval,
        )

        if args.skip_new_version:
            LOGGER.warning("Upgrade write complete. New version read skipped by --skip-new-version")
            return

        time.sleep(max(args.post_upgrade_delay, 0.2))
        new_version = read_version(bus, args.new_app_address, args.version_register)
        new_cp0_minor = None
        try:
            new_cp0_minor = read_version(bus, args.new_app_address, args.cp0_minor_register)
        except Exception as minor_exc:
            LOGGER.warning(
                "New APP software version was read, but CP0 minor register 0x%02X could not be read: %s",
                args.cp0_minor_register,
                minor_exc,
            )

        if state.old_sw_version is None:
            LOGGER.info("Upgrade complete. New software version: %s", format_sw_version(new_version))
        else:
            LOGGER.info(
                "Upgrade complete. SW {old} -> {new}".format(
                    old=format_sw_version(state.old_sw_version),
                    new=format_sw_version(new_version),
                )
            )
        if new_cp0_minor is not None:
            if state.old_cp0_minor is None:
                LOGGER.info("New CP0 minor version: 0x%02X", new_cp0_minor)
            else:
                LOGGER.info("CP0 minor version: 0x%02X -> 0x%02X", state.old_cp0_minor, new_cp0_minor)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Upgrade IO1/PY32 firmware through Linux I2C.",
        formatter_class=RawDefaultsHelpFormatter,
        epilog="""examples:
  Dry-run with logs:
    python3 ./upgrade_io1.py -b /dev/i2c-1 --dry-run -v --log-file dryrun.log

  Check firmware parsing only, without I2C access:
    python3 ./upgrade_io1.py --firmware-only

  Upgrade current 0x4F app firmware; prompts for firmware and final confirmation:
    python3 ./upgrade_io1.py -b /dev/i2c-1 -v --log-file upgrade.log

  Recover when IO1 is already in bootloader mode; auto-detected by default:
    python3 ./upgrade_io1.py -b /dev/i2c-1 -v --log-file recover.log

  Use another firmware file:
    python3 ./upgrade_io1.py -b /dev/i2c-1 -f "./firmwares/your_firmware.h" -v --log-file upgrade.log
""",
    )
    parser.add_argument("-b", "--bus", default="/dev/i2c-1", help="Linux I2C device")
    parser.add_argument(
        "-f",
        "--firmware",
        type=Path,
        default=argparse.SUPPRESS,
        help="Firmware .h or .bin file; without this, normal upgrade mode shows a firmware menu",
    )
    parser.add_argument("--old-app-address", type=parse_int, default=DEFAULT_APP_ADDRESS, help="Current app I2C address")
    parser.add_argument("--new-app-address", type=parse_int, default=DEFAULT_APP_ADDRESS, help="App I2C address after upgrade")
    parser.add_argument("--bootloader-address", type=parse_int, default=DEFAULT_BOOTLOADER_ADDRESS, help="Bootloader I2C address")
    parser.add_argument("--version-register", type=parse_int, default=DEFAULT_VERSION_REGISTER, help="App software-version register")
    parser.add_argument(
        "--cp0-minor-register",
        type=parse_int,
        default=DEFAULT_CP0_MINOR_REGISTER,
        help="App CP0 minor-version register",
    )
    parser.add_argument("--trigger-register", type=parse_int, default=DEFAULT_TRIGGER_REGISTER, help="App register used to enter bootloader")
    parser.add_argument("--trigger-value", type=parse_int, default=DEFAULT_TRIGGER_VALUE, help="Value written to trigger register")
    parser.add_argument("--application-address", type=parse_int, default=DEFAULT_APPLICATION_ADDRESS, help="PY32 application flash address")
    parser.add_argument("--page-size", type=int, default=DEFAULT_PAGE_SIZE, help="Firmware write page size in bytes")
    parser.add_argument("--enter-timeout", type=float, default=10.0, help="Seconds to wait for bootloader after trigger")
    parser.add_argument("--ready-timeout", type=float, default=10.0, help="Seconds to wait for bootloader before each page write")
    parser.add_argument("--exit-timeout", type=float, default=10.0, help="Seconds to wait for bootloader to jump back to app")
    parser.add_argument("--poll-interval", type=float, default=0.1, help="I2C address polling interval in seconds")
    parser.add_argument("--post-trigger-delay", type=float, default=0.1, help="Delay after writing trigger register")
    parser.add_argument("--post-upgrade-delay", type=float, default=0.3, help="Delay before reading new app version")
    parser.add_argument("--page-delay", type=float, default=0.05, help="Delay between firmware page writes")
    parser.add_argument(
        "--page-write-retries",
        type=int,
        default=DEFAULT_PAGE_WRITE_RETRIES,
        help="Retries for a failed bootloader page transfer",
    )
    parser.add_argument("--skip-old-version", action="store_true", help="Deprecated; current APP communication is still checked before flashing")
    parser.add_argument("--skip-new-version", action="store_true", help="Do not read the new app version after upgrade")
    parser.add_argument("--already-in-bootloader", action="store_true", help="Force bootloader flow and skip auto probe/app trigger")
    parser.add_argument("--dry-run", action="store_true", help="Auto probe and optionally read old version, but do not write firmware")
    parser.add_argument("--firmware-only", action="store_true", help="Load/parse firmware and exit before opening I2C")
    parser.add_argument("-v", "--verbose", action="store_true", help="Print detailed I2C debug logs")
    parser.add_argument("--log-file", type=Path, help="Write full logs to this file")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, "firmware"):
        args.firmware = None
    setup_logging(args)
    exit_code = 1

    try:
        upgrade(args)
    except UserCancelled as exc:
        LOGGER.warning("RESULT: CANCELLED - %s", exc)
        exit_code = 2
    except KeyboardInterrupt:
        LOGGER.warning("RESULT: CANCELLED - interrupted by user")
        exit_code = 130
    except Exception as exc:
        LOGGER.exception("RESULT: FAILED - %s", exc)
        exit_code = 1
    else:
        LOGGER.info("RESULT: SUCCESS")
        exit_code = 0
    finally:
        LOGGER.info("Exit code: %d", exit_code)

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
